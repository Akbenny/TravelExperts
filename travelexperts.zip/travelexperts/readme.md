# Demo project
A demo project for Express.js with MySQL, MongoDB, Mongoose